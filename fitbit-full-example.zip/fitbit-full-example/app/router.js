import * as index from './pages/index';
import * as detail from './pages/detail';
import * as listliked from './pages/listliked';

export default {
  index,
  detail,
  listliked,
};
